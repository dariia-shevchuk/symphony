<?php
// src/Controller/LuckyController.php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class LuckyController extends AbstractController
{
//    #[Route('/')]
//    public function number(): Response
//    {
//        $number = ['test' => 'value1','test2' => 'value2'];
//
//        return $this->render('lucky/number.html.twig', [
//            'numberVar' => $number,
//        ]);
//    }
}